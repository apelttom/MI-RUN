package cz.cvut.fit.run;

public class NativeMethod {
	
	public void main() {
		int fileName = 12345;
		int value = 666;
		fileWrite(fileName, value);
	}
}
