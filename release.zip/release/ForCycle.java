package cz.cvut.fit.run;

public class ForCycle {
	
	public void main() {
		int a = 5;
		int b = 10;
		for(int i = 0; i < b; i++){
			a = a + 1;
		}
	}
}
