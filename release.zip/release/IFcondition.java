package cz.cvut.fit.run;

public class IFcondition {
	
	public void main() {
		int a = 5;
		int b = 10;
		if(a > b){
			99;
		} else{
			22;
		}
		if(a == b){
			55;
		} else {
			44;
		}
	}
}
