package cz.cvut.fit.run;

public class Objects {
	
	public void main() {
		MyObject obj = new MyObject();
		int firstVar = obj.factorial(3);
		obj.changeGlobalVariable();
		int secondVar = obj.getFoo();
		obj.setFoo(88);
		int thirdVar = obj.getFoo();
		Point pointA = new Point();
		pointA.setCoordinate(5);
		Point pointB = new Point();
		pointB.setCoordinate(14);
		Line line = new Line();
		line.setPoints(pointA, pointB);
		int fourthVar = line.getLength();
	}
}

public class MyObject {
	int foo;
	
	public int factorial(int n){
		if(n == 0){
			return 1;
		}
		int result = n * factorial(n - 1);
		return result;
	}
	
	
	public void changeGlobalVariable(){
		foo = 10;
	}
	
	public int getFoo(){
		return foo;
	}
	
	public void setFoo(int n){
		foo = n;
	}
}

public class Point{
	int coordinate;
	
	public int getCoordinate(){
		return coordinate;
	}
	
	public void setCoordinate(int coord){
		coordinate = coord;
	}
}

public class Line{
	Point pointA;
	Point pointB;
	
	public void setPoints(Point a, Point b){
		pointA = a;
		pointB = b;
	}
	
	public int getLength(){
		int a = pointA.getCoordinate();
		int b = pointB.getCoordinate();
		int result = a - b;
		return result;
	}
}
