package cz.cvut.fit.run;

public class MethodInvocation {
	
	public void main() {
		int n = 3;
		factorial(n);
	}
	
	public int factorial(int n){
		if(n == 0){
			return 1;
		}
		int result = n * factorial(n - 1);
		return result;
	}
}
